package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class JsonUtils  {


    public static Sandwich parseSandwichJson(String json) {
        Sandwich sandwich;

        //make the string a json object
        try {
            JSONObject jsonObject = new JSONObject(json);
            //get name object
            JSONObject nameObject = jsonObject.getJSONObject("name");
            //get main name
            final String name = nameObject.getString("mainName");
            //get alsoKnownAs
            JSONArray alsoKnownAs = nameObject.getJSONArray("alsoKnownAs");
            //get place of origin
            final String placeOfOrigin = jsonObject.getString("placeOfOrigin");
            //get description
            final String description = jsonObject.getString("description");
            //get imageurl
            final String image = jsonObject.getString("image");
            //get ingredients
            JSONArray ingredients = jsonObject.getJSONArray("ingredients");

            //make a list of ingredients
            ArrayList<String> ingredientsList = new ArrayList<String>();
            for (int i=0;i<ingredients.length();i++){
                ingredientsList.add(ingredients.getString(i));
            }
            //make a list of alsoKnownAs
            ArrayList<String> alsoKnownNames = new ArrayList<String>();
            for (int i=0;i<alsoKnownAs.length();i++){
                alsoKnownNames.add(alsoKnownAs.getString(i));
            }

            sandwich = new Sandwich(name, alsoKnownNames, placeOfOrigin, description, image, ingredientsList);
            return sandwich;
        }
    catch (JSONException e) {
        throw new RuntimeException(e);
    }



    }
}
